/*
 * Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

(function () {
    "use strict";

    Office.initialize = function (reason) {
        $(document).ready(function () {
            $('#set-color').click(setColor);
			$('#add-expense').click(setColor);
        });
    };

    function setColor() {
        Excel.run(function (context) {
			//var ress = makeCall();
                
			
            var range = context.workbook.getSelectedRange();
            range.format.fill.color = 'green';

            return context.sync();
        }).catch(function (error) {
            console.log("Error: " + error);
            if (error instanceof OfficeExtension.Error) {
                console.log("Debug info: " + JSON.stringify(error.debugInfo));
            }
        });
    }
	
	
	function addExpense() {

		// Run a batch operation against the Excel object model
		Excel.run(function (ctx) {

			// Create a proxy object for the expense table rows
			//var tableRows = ctx.workbook.tables.getItem('expenseTable').rows;
			//tableRows.add(null, [[$("#expense-description").val(), $("#expense-cost").val(), $("#expense-category").val()]]);
			
			var ress = makeCall();
                ress.done(function (data, status, xhr) {
                    alert('file uploaded and updated');
                });
 

			
			


			// Run the queued-up commands, and return a promise to indicate task completion
			return ctx.sync();
		})
		.catch(function (error) {
			// Always be sure to catch any accumulated errors that bubble up from the Excel.run execution
			app.showNotification("Error: " + error);
			console.log("Error: " + error);
			if (error instanceof OfficeExtension.Error) {
				console.log("Debug info: " + JSON.stringify(error.debugInfo));
			}
		});
	}
	
	function makeCall() {
		var endPoint = jQuery('#expense-description').val();
		alert('file uploaded and updated');
		return jQuery.ajax({
            url: endPoint,
            type: "GET",
            //data: arrayBuffer,
            //processData: false,
            headers: {
                "accept": "application/json;odata=verbose",
                //"X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
                //"content-length": arrayBuffer.byteLength
            }
        });
		
		
		
	}
})();